# DB-Group1-Project4
Database Management group 1's project 4. IT Support Ticket System

How To Run Flask

Unix:
```
export FLASK_APP=ITsupport.py
flask run
```
Windows CMD:
```
set FLASK_APP=ITsupport.py
flask run
```
PowerShell:
```
$env:FLASK_APP="ITsupport.py"
flask run
```


TO DO:
- Update schema/load_data so that it does not error
- Add views for IT employees and users